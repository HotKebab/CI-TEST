<template>
  <main
    class="w-full bg-white rounded-lg shadow dark:border md:mt-4 md:mb-4 xl:p-1 dark:bg-gray-800 dark:border-gray-700"
  >
    <div class="text-center">
      <h1
        class="mt-10 mb-2 leading-none tracking-tight text-gray-600 md:text-5xl lg:text-6xl dark:text-white"
      >
        Todo App
      </h1>
      <p
        class="p-5 text-lg font-normal text-gray-900 lg:text-xl sm:px-16 xl:px-48 dark:text-gray-400"
      >
        Cette application offre une interface simple et intuitive pour la gestion de tâches. Chaque
        tâche peut être marquée comme "complétée" une fois terminée ou encore supprimée.
        L'application permet également gérer le profile de l'utilisateur connecté.
      </p>
    </div>
  </main>
</template>

<style scoped></style>
