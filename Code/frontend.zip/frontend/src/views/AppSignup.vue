<script setup lang="ts">
import ProfileSignup from '@/components/ProfileSignup.vue';
</script>

<template>
  <ProfileSignup />
</template>
