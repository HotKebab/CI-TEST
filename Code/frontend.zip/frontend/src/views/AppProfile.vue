<script setup lang="ts">
import ProfileEdit from '@/components/ProfileEdit.vue';
</script>

<template>
  <div class="d-flex flex-row align-center justify-content-center">
    <ProfileEdit />
  </div>
</template>
